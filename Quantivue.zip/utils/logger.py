import logging
from pathlib import Path

# Force log file into Quantivue root
BASE_DIR = Path(__file__).resolve().parent.parent
LOG_FILE = BASE_DIR / "quantivue.log"

logging.basicConfig(
    filename=str(LOG_FILE),
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    force=True
)

def log(message):
    logging.info(message)
