from sklearn.cluster import KMeans
from data_ingestion.loader import load_data
from data_ingestion.cleaner import clean_data


def cluster_spending(df):
    X = df[['amount']]

    model = KMeans(n_clusters=3, random_state=42)
    df['cluster'] = model.fit_predict(X)

    print("Spending Clusters:")
    print(df[['amount', 'cluster']])
    return df


if __name__ == "__main__":
    df = load_data("sample_transactions.csv")
    clean_df = clean_data(df)
    cluster_spending(clean_df)
