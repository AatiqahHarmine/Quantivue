from sklearn.ensemble import IsolationForest
from data_ingestion.loader import load_data
from data_ingestion.cleaner import clean_data


def detect_anomalies(df):
    X = df[['amount']]

    model = IsolationForest(contamination=0.2, random_state=42)
    df['anomaly'] = model.fit_predict(X)

    print("Anomaly Detection Results:")
    print(df[['amount', 'anomaly']])
    return df


if __name__ == "__main__":
    df = load_data("sample_transactions.csv")
    clean_df = clean_data(df)
    detect_anomalies(clean_df)
