import pandas as pd
from sklearn.linear_model import LinearRegression
from data_ingestion.loader import load_data
from data_ingestion.cleaner import clean_data


def forecast_expense(df):
    # Prepare data for model
    df = df.sort_values('date')
    df['day_number'] = range(len(df))

    X = df[['day_number']]
    y = df['amount']

    # Train model
    model = LinearRegression()
    model.fit(X, y)

    # Predict expense for next 30th day
    future_day = [[len(df) + 30]]
    prediction = model.predict(future_day)

    print(f"Predicted expense after 30 days: {prediction[0]}")
    return prediction[0]


if __name__ == "__main__":
    df = load_data("sample_transactions.csv")
    clean_df = clean_data(df)
    forecast_expense(clean_df)
