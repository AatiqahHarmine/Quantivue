from data_ingestion.loader import load_data
from data_ingestion.cleaner import clean_data
from analytics.expense_analysis import run_full_analysis


def calculate_financial_score(path):
    result = run_full_analysis(path)

    score = 100

    # Deduct based on anomalies
    score -= result['anomaly_count'] * 10

    # Deduct if predicted expense is too high
    if result['predicted_expense_next_30_days'] > 3000:
        score -= 20

    # Deduct if too many clusters (irregular spending)
    if result['clusters_found'] > 2:
        score -= 10

    final_score = max(score, 0)

    print(f"\nFinancial Health Score: {final_score}/100")
    return final_score


if __name__ == "__main__":
    calculate_financial_score("sample_transactions.csv")
