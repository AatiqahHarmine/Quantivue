from fastapi import FastAPI, UploadFile, File
import shutil
from utils.logger import log

from analytics.expense_analysis import run_full_analysis
from ml_models.financial_score import calculate_financial_score

app = FastAPI(title="Quantivue API")


@app.get("/")
def home():
    return {"message": "Welcome to Quantivue - Personal Financial Intelligence API"}


@app.post("/analysis")
def full_analysis(file: UploadFile = File(...)):
    log("File received for analysis")  

    file_path = f"temp_{file.filename}"

    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    result = run_full_analysis(file_path)
    return result


@app.post("/score")
def financial_score(file: UploadFile = File(...)):
    log("File received for score calculation")
    file_path = f"temp_{file.filename}"

    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    score = calculate_financial_score(file_path)
    return {"financial_health_score": score}
