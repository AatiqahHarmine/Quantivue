from data_ingestion.loader import load_data
from data_ingestion.cleaner import clean_data
from utils.logger import log
from ml_models.forecasting import forecast_expense
from ml_models.clustering import cluster_spending
from ml_models.anomaly_detection import detect_anomalies


def run_full_analysis(path):
    df = load_data(path)
    clean_df = clean_data(df)

    prediction = forecast_expense(clean_df)
    clustered_df = cluster_spending(clean_df)
    anomaly_df = detect_anomalies(clean_df)

    anomalies = anomaly_df[anomaly_df['anomaly'] == -1]

    result = {
        "predicted_expense_next_30_days": prediction,
        "total_transactions": len(clean_df),
        "anomaly_count": len(anomalies),
        "clusters_found": clustered_df['cluster'].nunique()
    }
    log("Running full financial analysis")
    print("\n=== Full Financial Insight ===")
    print(result)

    return result


if __name__ == "__main__":
    run_full_analysis("sample_transactions.csv")
