import ray

def start_ray():
    ray.init()
    print("Ray cluster started successfully!")


if __name__ == "__main__":
    start_ray()
