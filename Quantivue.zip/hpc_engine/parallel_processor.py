import ray
import numpy as np
import pandas as pd
from data_ingestion.loader import load_data
from data_ingestion.cleaner import clean_data

ray.init()


@ray.remote
def process_chunk(chunk_df):
    # Now this is a real DataFrame
    return chunk_df['amount'].sum()


def run_parallel_processing(df):
    # Properly split dataframe into DataFrame chunks
    chunks = [df.iloc[i:i+2] for i in range(0, len(df), 2)]

    # Send chunks to Ray workers
    futures = [process_chunk.remote(chunk) for chunk in chunks]

    results = ray.get(futures)

    total = sum(results)
    print(f"Total amount calculated in parallel: {total}")
    return total


if __name__ == "__main__":
    df = load_data("sample_transactions.csv")
    clean_df = clean_data(df)
    run_parallel_processing(clean_df)
