import pandas as pd
from data_ingestion.loader import load_data


def clean_data(df):
    # Convert date column to datetime
    df['date'] = pd.to_datetime(df['date'])

    # Remove any missing values
    df = df.dropna()

    print("Cleaned Data:")
    print(df.head())
    return df


if __name__ == "__main__":
    df = load_data("sample_transactions.csv")
    clean_df = clean_data(df)
