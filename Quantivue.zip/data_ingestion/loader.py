import pandas as pd

def load_data(path):
    df = pd.read_csv(path)
    print(df.head())
    return df

if __name__ == "__main__":
    load_data("sample_transactions.csv")
